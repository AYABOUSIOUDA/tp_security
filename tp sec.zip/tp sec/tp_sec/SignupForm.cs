﻿using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Windows.Forms;
using tp_sec;

namespace tp_sec
{
    public partial class SignupForm : Form
    {
        string apiKey = "AIzaSyCZLX3F4vpvZyghaQsrDrx1KQJ3-Lsrkps";
        bool IsValidPassword(string password)
        {
            if (password.Length < 10)
                return false;

            if (!password.Any(char.IsUpper))
                return false;

            if (!password.Any(ch => !char.IsLetterOrDigit(ch)))
                return false;

            return true;
        }

        public SignupForm()
        {
            InitializeComponent();
        }

        string GeneratePin()
        {
            return new Random().Next(100000, 999999).ToString();
        }

        void SendPinEmail(string toEmail, string pin)
        {
            var client = new SmtpClient("smtp.gmail.com", 587)
            {
                Credentials = new NetworkCredential("ayabousiouda@gmail.com", "gprrhqvcnnxtadwu"),
                EnableSsl = true
            };

            var msg = new MailMessage("ayabousiouda@gmail.com", toEmail,
                "PIN Verification",
                $"Your verification code is: {pin}");

            client.Send(msg);
        }

        private async void btnSignup_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Text;

            if (!IsValidPassword(password))
            {
                MessageBox.Show(
                    "Password must:\n" +
                    "- Be at least 10 characters\n" +
                    "- Contain at least one uppercase letter\n" +
                    "- Contain at least one special character (!@#$...) ❌");
                return;
            }

            var client = new HttpClient();
            var url = $"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={"AIzaSyCZLX3F4vpvZyghaQsrDrx1KQJ3 - Lsrkps"}";

            var data = new
            {
                email = email,
                password = password,
                returnSecureToken = true
            };

            var json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                string pin = GeneratePin();
                SendPinEmail(email, pin);

                VerifyPinForm v = new VerifyPinForm(pin);
                v.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Account creation failed❌");
            }
        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {

        }

        private void btnbackk_Click(object sender, EventArgs e)
        {
            LoginForm f = new LoginForm();
            f.Show();
            this.Hide();
        }
    }
}


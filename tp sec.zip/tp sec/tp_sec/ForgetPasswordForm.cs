﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace tp_sec
{
    public partial class ForgetPasswordForm : Form
    {
        string apiKey = "AIzaSyCZLX3F4vpvZyghaQsrDrx1KQJ3-Lsrkps";
        string generatedPin = "";
        string userEmail = "";

        public ForgetPasswordForm()
        {
            InitializeComponent();
            txtPin.Visible = false;
            btnVerifyPin.Visible = false;
        }

        // PIN
        string GeneratePin()
        {
            return new Random().Next(100000, 999999).ToString();
        }

        
        void SendPinEmail(string toEmail, string pin)
        {
            var client = new SmtpClient("smtp.gmail.com", 587)
            {
                Credentials = new NetworkCredential("ayabousiouda@gmail.com", "gprrhqvcnnxtadwu"),
                EnableSsl = true
            };

            var msg = new MailMessage(
                "ayabousiouda@gmail.com",
                toEmail,
                "Reset Password PIN",
                $"Your PIN code is: {pin}"
            );

            client.Send(msg);
        }

        // زر إرسال PIN
        private void btnSendPin_Click(object sender, EventArgs e)
        {
            userEmail = txtEmail.Text;

            if (string.IsNullOrEmpty(userEmail))
            {
                MessageBox.Show("Please enter your email.");
                return;
            }

            generatedPin = GeneratePin();
            SendPinEmail(userEmail, generatedPin);

            MessageBox.Show("A PIN has been sent to your email 📧");

            txtPin.Visible = true;
            btnVerifyPin.Visible = true;
        }

        // زر التحقق من PIN
        private async void btnVerifyPin_Click_1(object sender, EventArgs e)
        {
            if (txtPin.Text != generatedPin)
            {
                MessageBox.Show("Invalid PIN ❌");
                return;
            }

   
            var client = new HttpClient();
            var url = $"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={apiKey}";

            var data = new
            {
                requestType = "PASSWORD_RESET",
                email = userEmail
            };

            var json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            await client.PostAsync(url, content);

            MessageBox.Show("PIN verified ✅\nNow check your email to reset password 📧");

          
        }
        
        
            private async void btnSend_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text;

            var client = new HttpClient();
            var url = $"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={"AIzaSyCZLX3F4vpvZyghaQsrDrx1KQJ3-Lsrkps"}";

            var data = new
            {
                requestType = "PASSWORD_RESET",
                email = email
            };

            var json = JsonConvert.SerializeObject(data);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            var response = await client.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
                MessageBox.Show("A reset link was sent to your email. 📧");
            else
                MessageBox.Show("An error occurred ❌");

            LoginForm f = new LoginForm();
            f.Show();
            this.Hide();
        }
        private void btnback_Click(object sender, EventArgs e)
        {
            LoginForm f = new LoginForm();
            f.Show();
            this.Hide();
        }

        

        private void txtPin_TextChanged(object sender, EventArgs e)
        {

        }
    }
}



﻿namespace tp_sec
{
    partial class ForgetPasswordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btnback = new System.Windows.Forms.Button();
            this.btnSendPin = new System.Windows.Forms.Button();
            this.btnVerifyPin = new System.Windows.Forms.Button();
            this.txtPin = new System.Windows.Forms.TextBox();
            this.lable1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(473, 78);
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(478, 67);
            this.txtEmail.TabIndex = 1;
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(623, 460);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(200, 61);
            this.btnSend.TabIndex = 2;
            this.btnSend.Text = "Send Reset Link";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(385, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "Email";
            // 
            // btnback
            // 
            this.btnback.Location = new System.Drawing.Point(29, 618);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(231, 51);
            this.btnback.TabIndex = 4;
            this.btnback.Text = "back";
            this.btnback.UseVisualStyleBackColor = true;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // btnSendPin
            // 
            this.btnSendPin.Location = new System.Drawing.Point(473, 193);
            this.btnSendPin.Name = "btnSendPin";
            this.btnSendPin.Size = new System.Drawing.Size(164, 59);
            this.btnSendPin.TabIndex = 5;
            this.btnSendPin.Text = "Send Pin";
            this.btnSendPin.UseVisualStyleBackColor = true;
            this.btnSendPin.Click += new System.EventHandler(this.btnSendPin_Click);
            // 
            // btnVerifyPin
            // 
            this.btnVerifyPin.Location = new System.Drawing.Point(1008, 311);
            this.btnVerifyPin.Name = "btnVerifyPin";
            this.btnVerifyPin.Size = new System.Drawing.Size(146, 65);
            this.btnVerifyPin.TabIndex = 6;
            this.btnVerifyPin.Text = "VerifyPin";
            this.btnVerifyPin.UseVisualStyleBackColor = true;
            this.btnVerifyPin.Click += new System.EventHandler(this.btnVerifyPin_Click_1);
            // 
            // txtPin
            // 
            this.txtPin.Location = new System.Drawing.Point(473, 311);
            this.txtPin.Multiline = true;
            this.txtPin.Name = "txtPin";
            this.txtPin.Size = new System.Drawing.Size(478, 65);
            this.txtPin.TabIndex = 7;
            this.txtPin.TextChanged += new System.EventHandler(this.txtPin_TextChanged);
            // 
            // lable1
            // 
            this.lable1.AutoSize = true;
            this.lable1.Location = new System.Drawing.Point(364, 333);
            this.lable1.Name = "lable1";
            this.lable1.Size = new System.Drawing.Size(69, 20);
            this.lable1.TabIndex = 8;
            this.lable1.Text = "code pin";
            // 
            // ForgetPasswordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1478, 704);
            this.Controls.Add(this.lable1);
            this.Controls.Add(this.txtPin);
            this.Controls.Add(this.btnVerifyPin);
            this.Controls.Add(this.btnSendPin);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.txtEmail);
            this.Name = "ForgetPasswordForm";
            this.Text = "Reset Password";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnSendPin;
        private System.Windows.Forms.Button btnVerifyPin;
        private System.Windows.Forms.TextBox txtPin;
        private System.Windows.Forms.Label lable1;
    }
}
﻿using System;
using System.Windows.Forms;

namespace tp_sec
{
    public partial class VerifyPinForm : Form
    {
        string _pin = "";

        public VerifyPinForm()
        {
            InitializeComponent();
        }

        public VerifyPinForm(string pin)
        {
            InitializeComponent();
            _pin = pin;
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            if (txtPin.Text == _pin)
            {
                MessageBox.Show("Verified successfully ✅");

                LoginForm f = new LoginForm();
                f.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid PIN ❌");
            }
        }
    }
}



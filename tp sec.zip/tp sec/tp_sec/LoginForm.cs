﻿using System;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace tp_sec
{
    public partial class LoginForm : Form
    {
        string apiKey = "AIzaSyCZLX3F4vpvZyghaQsrDrx1KQJ3-Lsrkps";

        // 🔐 محاولات فاشلة
        public static int failedAttempts = 0;
        public static bool isBlocked = false;
        public static string currentPin = "";

        public LoginForm()
        {
            InitializeComponent();
        }


        //  إرسال PIN  في الايمايل

        private void SendPin(string toEmail)
        {
            //PIN عشوائي
            Random r = new Random();
            currentPin = r.Next(100000, 999999).ToString();

            try
            {
                // إعدادات SMTP
                SmtpClient smtp = new SmtpClient("smtp.gmail.com") 
                {
                    Port = 587,
                    Credentials = new NetworkCredential("ayabousiouda@gmail.com", "gprrhqvcnnxtadwu"), 
                    EnableSsl = true
                };

                MailMessage message = new MailMessage();
                message.From = new MailAddress("ayabousiouda@gmail.com");
                message.To.Add(toEmail);
                message.Subject = "Your Verification PIN 🔑";
                message.Body = $"Your PIN is: {currentPin}\nIt will be valid until you log in successfully.";

                smtp.Send(message);

                MessageBox.Show($"Your three attempts have expired. Please refer to the PIN code sent to {toEmail} to try registering again.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to send PIN ❌\n" + ex.Message);
            }
        }

        private async void btnLogin_Click(object sender, EventArgs e)
        {
            // ⛔ حساب مغلق
            if (isBlocked)
            {
                MessageBox.Show("Account blocked 🚫\nPlease verify PIN to continue.");
                SendPin(txtEmail.Text);
                VerifyPinForm f = new VerifyPinForm(currentPin);
                f.Show();
                this.Hide();
                return;
            }

            var client = new HttpClient();

            // 1️⃣ تسجيل الدخول
            var loginData = new
            {
                email = txtEmail.Text,
                password = txtPassword.Text,
                returnSecureToken = true
            };

            var loginJson = JsonConvert.SerializeObject(loginData);

            var loginResponse = await client.PostAsync(
                $"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={apiKey}",
                new StringContent(loginJson, Encoding.UTF8, "application/json")
            );

            //  فشل تسجيل الدخول
            if (!loginResponse.IsSuccessStatusCode)
            {
                failedAttempts++;

                if (failedAttempts >= 3)
                {
                    isBlocked = true;

                   
                    SendPin(txtEmail.Text);

                    VerifyPinForm f = new VerifyPinForm(currentPin);
                    f.Show();
                    this.Hide();
                    return;
                }

                MessageBox.Show("Email or password incorrect ❌");
                return;
            }

            // استخراج idToken
            var loginResult = await loginResponse.Content.ReadAsStringAsync();
            JObject loginObj = JObject.Parse(loginResult);

            string idToken = loginObj["idToken"]?.ToString();

            if (string.IsNullOrEmpty(idToken))
            {
                MessageBox.Show("Login failed ❌");
                return;
            }

            //emailVerified
            var lookupData = new { idToken = idToken };
            var lookupJson = JsonConvert.SerializeObject(lookupData);

            var lookupResponse = await client.PostAsync(
                $"https://identitytoolkit.googleapis.com/v1/accounts:lookup?key={apiKey}",
                new StringContent(lookupJson, Encoding.UTF8, "application/json")
            );

            var lookupResult = await lookupResponse.Content.ReadAsStringAsync();
            JObject lookupObj = JObject.Parse(lookupResult);

            JArray users = (JArray)lookupObj["users"];

            if (users == null || users.Count == 0)
            {
                MessageBox.Show("Failed to retrieve user data ❌");
                return;
            }

            bool emailVerified = users[0]["emailVerified"]?.ToObject<bool>() ?? false;

            //  الإيميل غير مفعل
            if (!emailVerified)
            {
                var emailData = new
                {
                    requestType = "VERIFY_EMAIL",
                    idToken = idToken
                };

                var emailJson = JsonConvert.SerializeObject(emailData);

                await client.PostAsync(
                    $"https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key={apiKey}",
                    new StringContent(emailJson, Encoding.UTF8, "application/json")
                );

                MessageBox.Show(
                    "Please verify your email first 📧\n" +
                    "A verification link has been sent to your email."
                );
                return;
            }

            // ✅ نجاح كامل
            failedAttempts = 0;
            isBlocked = false;

            MessageBox.Show("Login successful ✅");
        }

        private void lnkSignup_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SignupForm f = new SignupForm();
            f.Show();
            this.Hide();
        }

        private void lnkForget_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ForgetPasswordForm f = new ForgetPasswordForm();
            f.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Label clicked!");
        }
    }
}




